if __name__ == '__main__':
	from scrapegoat.main import getLinkData,generateData
	from scrapegoat import utils