if __name__ == '__main__':
	from scrapegoat.multiprocess import getLinkData,generateData
	from scrapegoat import utils